﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectFile1.bll;

namespace ProjectFile1.dal
{
    internal class Class2
    {

        static string myconnstring = ConfigurationManager.ConnectionStrings["connstring"].ConnectionString;
    }
}
