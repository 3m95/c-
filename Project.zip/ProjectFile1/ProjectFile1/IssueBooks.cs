﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectFile1
{
    public partial class IssueBooks : Form
    {
        public IssueBooks()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void IssueBooks_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=DESKTOP-0DFKLOH\\SQLEXPRESS; database=project; integrated security=True";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            conn.Open();
            cmd = new SqlCommand("SELECT bname FROM newbook", conn);
            SqlDataReader sqr = cmd.ExecuteReader();
            while (sqr.Read())
            {
                for (int i = 0; i < sqr.FieldCount; i++)
                {
                    comboBox1.Items.Add(sqr.GetString(i));
                }
            }
            sqr.Close();
            conn.Close();

        }
        int count;
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                string eid = textBox1.Text;
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = "Data Source=DESKTOP-0DFKLOH\\SQLEXPRESS; database=project; integrated security=True";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "select * from newstudent where enroll='" + eid + "' ";
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                //...................................................................................................
                //code to count how many books has been issued on this enrollement number
                cmd.CommandText = "select count(std_enroll) from IRBook where std_enroll='" + eid + "'and book_return_date is null ";
                SqlDataAdapter da1 = new SqlDataAdapter(cmd);
                DataSet ds1 = new DataSet();
                da.Fill(ds1);
                count = int.Parse(ds1.Tables[0].Rows[0][0].ToString());
                //...................................................................................................
                if (ds.Tables[0].Rows.Count != 0)
                {
                    textBox2.Text = ds.Tables[0].Rows[0][1].ToString();
                    textBox3.Text = ds.Tables[0].Rows[0][3].ToString();
                    textBox4.Text = ds.Tables[0].Rows[0][4].ToString();
                    textBox5.Text = ds.Tables[0].Rows[0][5].ToString();
                    textBox6.Text = ds.Tables[0].Rows[0][6].ToString();

                }
                else
                {
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    textBox5.Clear();
                    textBox6.Clear();
                    MessageBox.Show("InValid Enrollement No ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                if (comboBox1.SelectedIndex != -1 && count <= 2)
                {
                    //MessageBox.Show("Hello I am IN");
                    string enroll = textBox1.Text;
                    string sname = textBox2.Text;
                    string dep = textBox3.Text;
                    string sem = textBox4.Text;
                    Int64 contact = Int64.Parse(textBox5.Text);
                    string email = textBox5.Text;
                    string bname = comboBox1.Text;
                    string issue_date = dateTimePicker1.Text;

                    string eid = textBox1.Text;
                    SqlConnection conn = new SqlConnection();
                    conn.ConnectionString = "Data Source=DESKTOP-0DFKLOH\\SQLEXPRESS; database=project; integrated security=True";
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    conn.Open();
                    cmd.CommandText = "insert into IRTable(std_enroll,std_name,std_dep,std_sem,std_contact,std_email,book_name,book_issue_date) values ('" + enroll + "','" + sname + "','" + dep + "','" + sem + "'," + contact + ",'" + email + "','" + bname + "','" + issue_date + "');";
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Book issued", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("select book or maximum number of book has been issued", "no book", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Enter Valid Enrollement Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
           /* if (MessageBox.Show("Are You Sure?", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Warning))
            { }*/
                this.Close();
            
        }
    }
}
